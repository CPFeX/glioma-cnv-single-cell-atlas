Additional file 3. Source-backed patient-level sensitivity results

This archive contains existing, completed analysis outputs. No statistical inference
was rerun during manuscript/table preparation. Folder names identify the generating
stage. All regional samples from the same source-backed patient are aggregated;
cohort-prefixed DS3 patient identifiers are not treated as longitudinal pairs.

Study design: 83 samples, 57 patients (39 GBM, 2 LGG, 11 ndGBM, 5 rGBM).
Composition analyses: all 57 patients; explicit zero-count features and full denominators.
Pseudobulk program scores and overall malignant DE: 56 qualifying patients
(39 GBM, 2 LGG, 10 ndGBM, 5 rGBM). Program scores are cell-count-weighted
regional averages, while DE counts are summed before CPM normalization.
Patient-global composition/program tests: 20,000 label permutations, seed 1337,
BH correction within the reported families; pairwise bootstrap replicates: 5,000.

LGG DE contrasts were not tested because only two patients were available.
GBM-versus-ndGBM/rGBM contrasts are confounded by dataset origin.
Within-DS3 ndGBM-versus-rGBM DE is exploratory and unpaired; no genes pass
Welch FDR < 0.05 and absolute difference in mean log2(CPM + 1) >= 0.5.
This does not demonstrate equivalence. No patient-level ORA was performed.

Code: https://github.com/CPFeX/glioma-cnv-single-cell-atlas/tree/a3a8a136425ffb6dec2bdd776099eb44e84613ee/code/validation
Primary workflow archive: https://doi.org/10.5281/zenodo.23015399 (v1.0.1).
The patient-level sensitivity stage was added later and is NOT included in that DOI.

The original stage output_manifest.tsv files and run_info.json are preserved.
Their paths can refer to the originating local analysis workspace. The root
FILE_MANIFEST.tsv provides the actual archive-relative paths, sizes and SHA256 hashes.
Some earlier comparison tables are retained only as diagnostics; the authoritative
outputs are in the three explicitly named stage folders in this archive.
